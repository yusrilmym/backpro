<?php $__env->startSection('title', 'data'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Data/</span>Perhitungan</h4>



<!-- Basic Layout -->
<div class="row">
  <div class="col-xxl">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Hitung IMT</h5> <small class="text-muted float-end">Default label</small>
      </div>
      <div class="card-body">
        <form action="calculation" method="POST">
        <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label class="form-label">Berat Badan</label>
            <input type="number" step="0.1" class="form-control" name="beratnumber" placeholder="Masukan Berat Badan Anda" />
          </div>
          <div class="mb-3">
            <label class="form-label">Tinggi Badan</label>
            <input type="number" step="0.1" class="form-control" name="tingginumber" placeholder="Masukan Tinggi Badan Anda" />
          </div>
          <button type="submit" class="btn btn-primary">Send</button>
        </form>
      </div>
    </div>
    <div class="row">
        <div class="col-md-3 m-auto">
            <?php if(session('message')): ?>
            <div class="alert alert-warning">
                <div class="text-center"><?php echo e(session('message')); ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
  </div>
    <div class="col-xxl">
        <div class="card mb-4">
          <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0">Hitung Normalisasi</h5> <small class="text-muted float-end">Merged input group</small>
          </div>
          <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="datanormalisasi" method="POST">
            <?php echo csrf_field(); ?>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Nama</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-user"></i></span>
                    <input type="text" name="name" class="form-control" placeholder="Masukan Nama anda" />
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Jenis Kelamin</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <div class="form-check mt-3">
                      <input name="kelamin" class="form-check-input" type="radio" value="l" id="defaultRadio1" />
                      <label class="form-check-label" for="defaultRadio1">
                        Laki - Laki
                      </label>
                    </div>
                    <div class="input-group input-group-merge">
                    </div>
                    <div class="form-check mt-3">
                      <input name="kelamin" class="form-check-input" type="radio" value="p" id="defaultRadio1" />
                      <label class="form-check-label" for="defaultRadio1">
                        Perempuan
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Nama Orang tua</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-group"></i></span>
                    <input type="text" name="namaortu" class="form-control" placeholder="Masukan Nama Orang Tua" />
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Usia</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-plus"></i></span>
                    <input type="number" name="age" class="form-control"placeholder="Masukan Usia anda" />
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Berat Badan</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-body"></i></span>
                    <input type="number" name="berat" step="0.1" class="form-control" placeholder="Masukan Berat Badan anda"/>
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Tinggi Badan</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-group"></i></span>
                    <input type="number" name="tinggi" step="0.1" class="form-control" placeholder="Masukan Tinggi Badan anda"/>
                  </div>
                </div>
              </div>
              
              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Send</button>
                </div>
              </div>
            </form>
          </div>
        </div>
    </div>
    <!-- Responsive Table -->
<div class="card">
    <h5 class="card-header">Data Training Hasil Normalisasi</h5>
    <div class="table-responsive text-nowrap">
      <table class="table">
        <thead>
          <tr class="text-nowrap">
            <th>#</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Nama Orang Tua</th>
            <th>Usia</th>
            <th>Berat Badan</th>
            <th>Tinggi Badan</th>
            <th>IMT</th>
            <th>BP</th>
            <th>penilaian</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->kelamin); ?></td>
                <td><?php echo e($row->namaortu); ?></td>
                <td><?php echo e($row->age); ?></td>
                <td><?php echo e($row->berat); ?></td>
                <td><?php echo e($row->tinggi); ?></td>
                <td><?php echo e($row->imt); ?></td>
                <td><?php echo e($row->bp); ?></td>
                <td><?php echo e($row->penilaian); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelyusvis/resources/views/content/dashboard/data.blade.php ENDPATH**/ ?>