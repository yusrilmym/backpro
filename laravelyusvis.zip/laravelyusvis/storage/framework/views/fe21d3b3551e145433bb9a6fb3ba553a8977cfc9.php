<?php $__env->startSection('title', 'data'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hitung/</span>Backpropagation</h4>

<?php $list = Session::get('list'); ?>

<!-- Basic Layout -->
<div class="row">
    <div class="col-xxl">
        <div class="card mb-4">
          <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0">Hitung Backpropagation</h5> <small class="text-muted float-end">Merged input group</small>
          </div>
          <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="hitungbackpro" method="POST">
            <?php echo csrf_field(); ?>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Usia</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-plus"></i></span>
                    <input type="number" step="any" name="usiabackpro" class="form-control"placeholder="Masukan Usia anda" />
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Berat Badan</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-body"></i></span>
                    <input type="number" step="any" name="beratbackpro" class="form-control" placeholder="Masukan Berat Badan anda"/>
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">Tinggi Badan</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-group"></i></span>
                    <input type="number" step="any" name="tinggibackpro" class="form-control" placeholder="Masukan Tinggi Badan anda"/>
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-icon-default-fullname">IMT Anda</label>
                <div class="col-sm-10">
                  <div class="input-group input-group-merge">
                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-repost"></i></span>
                    <input type="number" step="any" name="imtbackpro" class="form-control" placeholder="Masukan IMT anda"/>
                  </div>
                </div>
              </div>
              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Send</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        
    </div>
    <!-- Responsive Table -->
    <!-- Bordered Table -->
  

  

  <div class="card">
    <h5 class="card-header">Pengaktifan Bobot (Aktivasi Sigmoid)</h5>
    <div class="card-body">
      <div class="table-responsive text-nowrap">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>No</th>
              <th>Yk</th>
              <th>Nilai</th>    
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Gizi Buruk</td>
              <td><?php echo e((session('ngas'))); ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Gizi Kurang</td>
                <td><?php echo e(session('ngkas')); ?></td>
              </tr>
            <tr>
              <td>3</td>
              	<td>Gizi Baik</td>	
                <td><?php echo e(session('ngbas')); ?></td>
            </tr>
            <tr>
                <td>4</td>	
                <td>Beresiko Gizi Lebih</td>
                <td><?php echo e(session('ngzas')); ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>Gizi Lebih</td>
                <td><?php echo e(session('nglas')); ?></td>
            </tr>
            <tr>
                <td>6</td>
                <td>Obesitas</td>
                <td><?php echo e(session('ngoas')); ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php if(session('ngas') >= 0.956 && session('ngas') <= 0.96): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Gizi Buruk</h4>
<?php elseif(session('ngas') >= 0.930 && session('ngas') <= 0.941): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Gizi Kurang</h4>
<?php elseif(session('ngas') >= 0.847 && session('ngas') <= 0.876): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Gizi Baik</h4>
<?php elseif(session('ngas') >= 0.930 && session('ngas') <= 0.952): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Beresiko Gizi Lebih</h4>
<?php elseif(session('ngas') >= 0.950 && session('ngas') <= 0.963): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Gizi Lebih</h4>
<?php elseif(session('ngas') >= 0.932 && session('ngas') <= 0.947): ?>
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Hasil Gizi anda adalah </span>Obesitas</h4>
<?php endif; ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravelyusvis/resources/views/content/dashboard/backpro.blade.php ENDPATH**/ ?>